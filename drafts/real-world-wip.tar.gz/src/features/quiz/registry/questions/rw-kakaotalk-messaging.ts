import type { QuizQuestion } from "../types";

export const RW_KAKAOTALK_MESSAGING: QuizQuestion[] = [
  {
    id: "rw-kakaotalk-messaging-1",
    post: "rw-kakaotalk-messaging",
    question: "Actionbase에서 \"이 상품을 몇 명이 담았나\"를 물으면 COUNT가 빠르게 답한다. 이유는?",
    choices: [
      "Redis 캐시를 앞에 두고 배치로 갱신해서",
      "간선이 쓰일 때 카운터를 미리 올리거나 내려 두고, 읽을 때는 그 값을 그대로 꺼내서",
      "질의할 때 HBase를 병렬로 훑어 세서",
      "MySQL의 COUNT 인덱스를 써서",
    ],
    answer: 1,
    explanation:
      "Actionbase는 쓰기 시점에 State, Index, Count를 미리 계산한다. COUNT는 카운터 하나를 읽을 뿐 간선을 세지 않는다. 배치와 Redis로 수를 계산한 건 옮기기 전의 구조다.",
    anchor: "읽을-때-세지-않고-쓸-때-고쳐-둔다",
  },
  {
    id: "rw-kakaotalk-messaging-2",
    post: "rw-kakaotalk-messaging",
    question: "like(t=100), unlike(t=200), like(t=300)이 like 100 → like 300 → unlike 200 순서로 도착했다. 최종 상태와 카운트는?",
    choices: [
      "INACTIVE, 0 — 마지막에 도착한 것이 unlike라서",
      "ACTIVE, 2 — like가 두 번 와서",
      "ACTIVE, 1 — 가장 늦은 시각의 행동이 like라서",
      "INACTIVE, 1 — 카운트는 되돌리지 않아서",
    ],
    answer: 2,
    explanation:
      "상태는 도착 순서가 아니라 이벤트에 붙은 시각으로 정한다. createdAt 300이 deletedAt 200보다 크니 활성이고, 이미 활성인 상태에서 온 like는 카운트를 다시 올리지 않는다. 그래서 어떤 순서로 와도 ACTIVE, 1이다.",
    anchor: "눌렀다-취소했다-다시-누른-신호가-뒤섞여-도착한다",
  },
  {
    id: "rw-kakaotalk-messaging-3",
    post: "rw-kakaotalk-messaging",
    question: "Actionbase가 클라이언트 시각으로 상태를 정하는 방식의 가장 큰 전제는?",
    choices: [
      "이벤트에 시각을 붙이는 쪽의 시계를 믿을 수 있어야 한다",
      "모든 이벤트가 정확히 한 번만 도착해야 한다",
      "Kafka 파티션이 하나뿐이어야 한다",
      "HBase batch가 원자적이어야 한다",
    ],
    answer: 0,
    explanation:
      "늦은 시각이 이기는 규칙이라 시각이 틀리면 최종 상태도 틀린다. 중복 도착은 같은 결과를 내므로 문제가 되지 않는다. 그래서 시각을 앱이 붙일지 앞단 서버가 붙일지부터 정해야 한다.",
    anchor: "눌렀다-취소했다-다시-누른-신호가-뒤섞여-도착한다",
  },
  {
    id: "rw-kakaotalk-messaging-4",
    post: "rw-kakaotalk-messaging",
    question: "카카오가 HBase와 Redicoke 중 HBase를 고른 이유로 문서가 드는 것은?",
    choices: [
      "HBase만 수평 확장을 지원해서",
      "Redicoke가 Redis 프로토콜을 쓰지 않아서",
      "HBase가 메모리 사용량이 더 적어서",
      "대규모 데이터를 bulk loading으로 옮기는 데 더 맞아서",
    ],
    answer: 3,
    explanation:
      "FAQ는 두 후보 모두 수평 확장, 내구성, 낮은 지연을 준다고 적고, HBase를 고른 이유로 bulk loading을 통한 대규모 이관을 든다. 기존 서비스 데이터를 통째로 옮겨 와야 했으니 이관 도구가 선택을 갈랐다.",
    anchor: "왜-hbase였나",
  },
  {
    id: "rw-kakaotalk-messaging-5",
    post: "rw-kakaotalk-messaging",
    question: "State, Index, Count를 함께 쓰는데도 Actionbase가 주기적으로 셋을 맞춰 보는 이유는?",
    choices: [
      "CDC가 가끔 이벤트를 두 번 내보내서",
      "HBase batch는 원자적이지 않아 region 서버 장애 때 일부만 쓰일 수 있어서",
      "카운터가 오래되면 자동으로 0이 되어서",
      "클라이언트가 Index를 직접 고칠 수 있어서",
    ],
    answer: 1,
    explanation:
      "운영 글은 HBase batch가 원자적이지 않아 State는 바뀌었는데 Index는 안 바뀐 상태가 생길 수 있다고 적는다. 그래서 스냅숏을 내보내 비교하고, 진실인 State에서 Index와 Count를 다시 만든다.",
    anchor: "함께-쓴다고-했지만-원자적이지-않다",
  },
  {
    id: "rw-kakaotalk-messaging-6",
    post: "rw-kakaotalk-messaging",
    question: "위시 이관의 비교 단계에서 HBase를 직접 읽지 않고 CDC로 쌓은 스냅숏을 MySQL 덤프와 비교한 이유는?",
    choices: [
      "HBase는 직접 읽을 수 없는 저장소라서",
      "CDC 스냅숏이 더 작아서 비교가 빨라서",
      "원본에서 CDC까지 파이프라인 전체가 맞아야 일치하므로 그 길 전체를 함께 검증할 수 있어서",
      "MySQL 덤프의 시각과 정확히 맞출 수 있어서",
    ],
    answer: 2,
    explanation:
      "같은 데이터를 독립된 길로 만들어 비교하면 어느 단계가 틀려도 불일치로 드러난다. 덤프와 CDC 스냅숏의 시각은 오히려 정확히 맞지 않아서, 경계 데이터는 다음 비교 창으로 넘긴다.",
    anchor: "끄지-않고-옮겨-간-다섯-단계",
  },
  {
    id: "rw-kakaotalk-messaging-7",
    post: "rw-kakaotalk-messaging",
    question: "선물하기 최근 본 상품을 queue=true로 비동기 처리한 판단의 근거로 맞는 것은?",
    choices: [
      "쓰기 양이 많고, 수십 밀리초 늦게 반영돼도 사용자가 문제 삼지 않는 데이터라서",
      "최근 본 상품은 HBase에 저장할 수 없어서",
      "비동기로 하면 잠금이 필요 없어 정확도가 올라가서",
      "위시와 달리 카운터가 필요 없어 WAL이 필요 없어서",
    ],
    answer: 0,
    explanation:
      "최근 본 상품은 상품을 볼 때마다 이벤트가 생겨 쓰기가 훨씬 많다. 요청 경로에서 동기로 처리하면 응답이 느려지고 몰릴 때 역압이 생긴다. WAL에 붙이고 바로 응답한 뒤 처리기가 감당할 속도로 반영하며, 보통 수십 밀리초 안에 반영된다.",
    anchor: "모든-쓰기를-그-자리에서-처리하지-않는다",
  },
];
